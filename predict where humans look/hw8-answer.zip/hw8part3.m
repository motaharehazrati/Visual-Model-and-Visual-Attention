clear all; 
close all; 
clc;
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\DatabaseCode (1)\DatabaseCode');
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel');
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\matlabPyrTools-master\matlabPyrTools-master');
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\SaliencyToolbox2.3\SaliencyToolbox')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\voc-release-3.1-win-master\voc-release-3.1-win-master')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\FaceDetect')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\LabelMeToolbox-master\LabelMeToolbox-master')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel\horizon code')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\LabelMeToolbox-master\LabelMeToolbox-master\features')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\LabelMeToolbox-master\LabelMeToolbox-master\imagemanipulation')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel\FelzenszwalbDetectors')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\ALLSTIMULI')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\matlabPyrTools-master\matlabPyrTools-master\MEX')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\gbvs\gbvs\util')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\DATA\hp')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\ALLSTIMULI')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\LabelMeToolbox-master\LabelMeToolbox-master\objectdetection')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\ALLFIXATIONMAPS\ALLFIXATIONMAPS')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\DatabaseCode (1)\DatabaseCode')
name = 'i1163635870';

data = load(i1163635870.mat');
data = struct2cell(data);
data = data{1};
data = data.DATA.eyeData;
[eyeData Fix Sac] = checkFixations(data);
fixs = find(eyeData(:,3)==0);
% saliencyMap = saliency('i13910717.jpeg')
img = imread('i1163635870.jpeg');
origimgsize = size(img);
x = eyeData(:,1);
y = eyeData(:,2);
dis = 360;
x1 = x(1:dis);
x2 = x(725-dis+1:end);
y1 = y(1:dis);
y2 = y(725-dis+1:end);
saliencyMap = saliency('i1163635870.jpeg');
img1=saliencyMap;
imshow(img1);
hold on
plot(x1,y1,'y.','MarkerSize',14);
hold on
plot(x2,y2,'b.','MarkerSize',14);

% score = rocScoreSaliencyVsFixations(img1,x1,y1,origimgsize);