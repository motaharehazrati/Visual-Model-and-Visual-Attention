clear all;
close all;
clc
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\DatabaseCode (1)\DatabaseCode');
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel');
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\matlabPyrTools-master\matlabPyrTools-master');
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\SaliencyToolbox2.3\SaliencyToolbox')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\voc-release-3.1-win-master\voc-release-3.1-win-master')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\FaceDetect')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\LabelMeToolbox-master\LabelMeToolbox-master')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel\horizon code')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\LabelMeToolbox-master\LabelMeToolbox-master\features')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\LabelMeToolbox-master\LabelMeToolbox-master\imagemanipulation')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel\FelzenszwalbDetectors')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\ALLSTIMULI')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\matlabPyrTools-master\matlabPyrTools-master\MEX')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\gbvs\gbvs\util')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\DATA\hp')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\ALLSTIMULI')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\LabelMeToolbox-master\LabelMeToolbox-master\objectdetection')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\ALLFIXATIONMAPS\ALLFIXATIONMAPS')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\DatabaseCode (1)\DatabaseCode')
function saliencyMap=salineccy(img)
% img = imread(imgName);
[w, h, c] = size(img);
dims = [200, 200];
    FEATURES(:, 1:13) = findSubbandFeatures(img, dims);
    FEATURES(:, 14:16) = findIttiFeatures(img, dims);
    FEATURES(:, 17:27) = findColorFeatures(img, dims);
    FEATURES(:, 28) = findTorralbaSaliency(img, dims);
    %FEATURES(:, 29) = findHorizonFeatures(img, dims);
    %FEATURES(:, 30:31) = findObjectFeatures(img, dims);
    %FEATURES(:, 32) = findDistToCenterFeatures(img, dims);
lengthF = length((FEATURES(1,:)));
load model
% feat={FEATURES(:, 1:13) FEATURES(:, 14:16) FEATURES(:, 17:27) FEATURES(:, 28) FEATURES(:, 29) FEATURES(:, 30:31) FEATURES(:, 32)};

% load the model
% This model has been created to run with all the above 33 features
% If you'd like to run a model that has DIFFERENT features, you have to
% train your own model.  You can do this using the TrainAndTestModel code
% available on our website
% http://people.csail.mit.edu/tjudd/WherePeopleLook/Code/TrainAndTestModel.zip
load model

% whiten the feature data with the parameters from the model.
% for i=1:7
    meanVec = model.whiteningParams(1, lengthF);
    stdVec = model.whiteningParams(2, lengthF);
    FEATURES=FEATURES-repmat(meanVec, [size(FEATURES, 1), 1]);
    FEATURES=FEATURES./repmat(stdVec, [size(FEATURES, 1), 1]);

    % find the saliency map given the features and the model
    saliencyMap = (FEATURES*model.w(1:lengthF)') + model.w(end);
    saliencyMap = (saliencyMap-min(saliencyMap))/(max(saliencyMap)-min(saliencyMap));
    saliencyMap = reshape(saliencyMap, dims);
    saliencyMap = imresize(saliencyMap, [w, h]);
% end
end
load IMAGES.mat;
map = {};
for i = 1:10
    img = IMAGES(:,:,i);
    img = repmat(img,1,1,3);
    [saliencyMap] = saliency(img,10);
    map{i} = saliencyMap;
end
pSize = 8;
p = [];
th = 30;
cnt = 1;
b=1;
n=1;
k=zeros(128,128);
for i = 1:10
    n=1;
    img = IMAGES(:,:,i);
    salMap = map{i};
    step = pSize - pSize/2;
    for r = 1:step:size(img,1)-step
        for c = 1:step:size(img,2)-step
            pTmp = img(r:r+pSize-1,c:c+pSize-1);
            pTmp = reshape(pTmp,pSize^2,1);
            sc = sum(salMap(r:r+pSize-1,c:c+pSize-1),'all');
            if (sc >= th)
             %   p(:,cnt) = pTmp;
             k(b,n,i)=1;   
            end
            cnt = cnt + 1;
            b=b+1;
        end
        n=n+1;
        b=1;
    end
%     im{i}=p;
%     cnt=1;
%     p=[];
end
A = rand(256) - 0.5;
A = A*diag(1./sqrt(sum(A.*A)));
figure(1), colormap(gray)
sparsenet