clear all; close all; clc;
rng shuffle
load IMAGES.mat
addpath('C:/Users/motahare/Desktop/hw9/sparsenet/sparsenet');
% A = rand(256) - 0.5;
% A = A*diag(1./sqrt(sum(A.*A)));
% figure(1), colormap(gray)
% sparsenet
for i=1:10
    subplot(2,5,i);
    imshow(IMAGES(:,:,i));
end
% mex -v cgf.c
% addpath('C:/Users/motahare/Desktop/hw9/gcc_maci64.xml');
% cp gcc_maci64.xml /Program Files/MATLAB/R2018a/bin/win64/mexopts
%compile mex files
% mex -v sparsenet/sparsenet/cgf.c sparsenet/sparsenet/nrf/brent.c sparsenet/sparsenet/nrf/frprmn.c sparsenet/sparsenet/nrf/linmin.c sparsenet/sparsenet/nrf/mnbrak.c sparsenet/sparsenet/nrf/nrutil.c -Inrf

% cp gcc_maci64.xml /Program Files/MATLAB/R2018a/bin/win64/mexopts




