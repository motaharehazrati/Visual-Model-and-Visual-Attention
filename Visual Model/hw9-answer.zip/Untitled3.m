% clear all; close all; clc;
% 
% obj = VideoReader('BIRD.avi');
% vid = read(obj);
% frames = obj.NumberOfFrames;
% for i = 1 : frames
%     tmp = rgb2gray(vid(:, :, :, i));
%     tmp = im2double(tmp);
%     crop = imcrop(tmp,[0,0,280,280]);
%     Vid(:,:,i) = crop;
% end
% 
%
% 
% for i = 1:10:110
%     tmp = Vid(:,:,i:i+9);
%     tmp2 = whitening(tmp);   
%         IMAGES{round(i/10+1)} = a
% end
%
% clear
% load IMAGE.mat
% A = rand(256) - 0.5;
% A = A*diag(1./sqrt(sum(A.*A)));
% figure(1), colormap(gray)
% sparsenet

load A.mat
load IMAGES_holder.mat
addpath('C:\Users\motahare\Desktop\hw9\sparsenet\sparsenet');
patchSize = 8;
noise_var = 0.01;
beta = 2.2;
sigma = 0.316;
tol = 0.01;

for f = 1:10
    imags = IMAGES{f};
    X = [];
        for j = 1:10
            img = imags(:,:,j);
            X = [X,patcher(img,patchSize)];
        end
        S{f} = cgf_fitS(A,X,noise_var,beta,sigma,tol);
 
end



% 
% 
% 
figure;
 x=[];
for i = 1:10
    tmp = S{i};
    avg = (abs(tmp));
    x = [x,avg];
    plot(avg+i*5,'linewidth',1.5);
    hold on
end

ylabel("Time")
xlabel("Coefficient")
title("coefficients over all")

% %Histograms
% figure;
% for i = 1:10
%     tmp = S{i};
%     x = reshape(tmp,size(tmp,1)*size(tmp,2),1);
% %     x = abs(x);
%     subplot(2,5,i);
%     hist(x,30)

% end


function IMAGES = whitening(images)
    N = size(images,1);
    imgNum = size(images,3);
    M = imgNum;
    [fx, fy]=meshgrid(-N/2:N/2-1,-N/2:N/2-1);
    rho=sqrt(fx.*fx+fy.*fy);
    f_0=0.4*N;
    filt=rho.*exp(-(rho/f_0).^4);
    for i=1:M
        image=images(:,:,i);
        If=fft2(image);
        imagew=real(ifft2(If.*fftshift(filt)));
        IMAGES(:,:,i) = imagew;
    end
    IMAGES=sqrt(0.1)*IMAGES./sqrt(mean(var(IMAGES)));
end



function [X] = patcher(img,patchSize)
    sz = size(img);
    p = {};
    inds1 = 1:patchSize:sz(1)-patchSize;
    inds2 = 1:patchSize:sz(2)-patchSize;
    for i = 1:length(inds1)
        i1 = inds1(i);
        for j = 1:length(inds2)
            j1 = inds2(j);
            p{(i-1)*length(inds2) + j} = img(i1:i1+patchSize-1,j1:j1+patchSize-1);
            X(:,(i-1)*length(inds2) + j) = reshape(img(i1:i1+patchSize-1,j1:j1+patchSize-1),patchSize^2,1);
        end
    end
    
end
