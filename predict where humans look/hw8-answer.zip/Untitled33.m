clear
clc
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\DatabaseCode (1)\DatabaseCode');
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel');
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\matlabPyrTools-master\matlabPyrTools-master');
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\SaliencyToolbox2.3\SaliencyToolbox')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\voc-release-3.1-win-master\voc-release-3.1-win-master')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\FaceDetect')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\LabelMeToolbox-master\LabelMeToolbox-master')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel\horizon code')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\LabelMeToolbox-master\LabelMeToolbox-master\features')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\LabelMeToolbox-master\LabelMeToolbox-master\imagemanipulation')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\JuddSaliencyModel\JuddSaliencyModel\FelzenszwalbDetectors')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\ALLSTIMULI')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\matlabPyrTools-master\matlabPyrTools-master\MEX')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\gbvs\gbvs\util')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\DATA\hp')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\ALLSTIMULI')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\LabelMeToolbox-master\LabelMeToolbox-master\objectdetection')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\ALLFIXATIONMAPS\ALLFIXATIONMAPS')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\DatabaseCode (1)\DatabaseCode')
addpath('C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\DATA\jw')
datafolder = 'C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\DATA\jw';
stimfolder = 'C:\Users\motahare\Desktop\hw8\Eye tracking database\Eye tracking database\Eye tracking database\ALLSTIMULI';
files=dir(fullfile(datafolder,'*.mat'));
[filenames{1:size(files,1)}] = deal(files.name);
stimulinumber = size(filenames,2);



score1 = [];
score2 = [];

for i = 1:100
   
    load(fullfile(datafolder,filenames{i}))
    stimFile = eval([filenames{i}(1:end-4)]);
    eyeData = stimFile.DATA.eyeData;
    [eyeData Fix Sac] = checkFixations(eyeData);
    fixs = find(eyeData(:,3)==0);
    imgname = stimFile.imgName;
    img = imread(imgname);
    [map] = saliency(imgname);
    dis = 180;
    x = eyeData(:,1);
    y = eyeData(:,2);
    x1 = x(10:dis);
    y1 = y(10:dis);
    x2 = x(end-dis+1:end);
    y2 = y(end-dis+1:end);
    origimgsize = size(img);
    score1(1,i) = rocScoreSaliencyVsFixations(map,x1,y1,origimgsize);
    score1(2,i) = rocScoreSaliencyVsFixations(map,x2,y2,origimgsize);

end


[counts1,centers1] = hist(score1(1,:),10);
[counts2,centers2] = hist(score1(2,:),10);
plot(centers1,counts1,'y','LineWidth',2);
hold on
plot(centers2,counts2,'b','LineWidth',2);
figure
bar(centers2,counts2,'facecolor','b')
hold on
bar(centers1,counts1,'facecolor','y')
title('all features')
xlabel("Score")
